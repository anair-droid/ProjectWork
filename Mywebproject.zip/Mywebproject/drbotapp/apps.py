from django.apps import AppConfig


class DrbotappConfig(AppConfig):
    name = 'drbotapp'
